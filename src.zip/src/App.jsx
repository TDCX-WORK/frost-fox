import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Home from './pages/Home/Home'
import AcademyPage from './pages/Academy/AcademyPage'

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/academy" element={<AcademyPage />} />
      </Routes>
    </BrowserRouter>
  )
}

export default App
