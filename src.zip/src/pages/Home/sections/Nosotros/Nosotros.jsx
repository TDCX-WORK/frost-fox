import { useRef, useState } from "react"
import { motion } from "motion/react"
import styles from "./Nosotros.module.css"
import ffLogo from "../../../../assets/ff-logo-gris.webp"
import { FlickeringGrid } from "@/components/ui/flickering-grid"

// ─────────────────────────────────────────────────────────────
// DATOS
// ─────────────────────────────────────────────────────────────
const PILARES = [
  {
    num: "01",
    tag: "WebDev",
    headline: "Presencia digital\nque escala.",
    body: "Webs y apps a medida. Desde corporativas hasta plataformas complejas.",
  },
  {
    num: "02",
    tag: "Academy",
    headline: "Educación técnica\ndigitalizada.",
    body: "SaaS B2B para academias que dan el salto al 100% digital.",
  },
  {
    num: "03",
    tag: "Talent",
    headline: "Conocimiento\nque permanece.",
    body: "Outsourcing estratégico. El profesional cambia de empleador, no de proyecto.",
  },
]

// ─────────────────────────────────────────────────────────────
// PILAR CARD — hover reveal oscuro
// ─────────────────────────────────────────────────────────────
function PilarCard({ p, i }) {
  const [hovered, setHovered] = useState(false)

  return (
    <motion.div
      className={styles.pilarCard}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      initial={{ opacity: 0, y: 32 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, delay: i * 0.12, ease: [0.16, 1, 0.3, 1] }}
    >
      {/* Fondo oscuro que aparece en hover */}
      <motion.div
        className={styles.pilarBg}
        animate={{ opacity: hovered ? 1 : 0 }}
        transition={{ duration: 0.35 }}
      />

      <div className={styles.pilarTop}>
        <span className={styles.pilarNum}>{p.num}</span>
        <span className={styles.pilarTag}>{p.tag}</span>
      </div>

      <h3 className={styles.pilarHeadline}>
        {p.headline.split("\n").map((l, j) => <span key={j}>{l}<br /></span>)}
      </h3>

      <motion.p
        className={styles.pilarBody}
        animate={{ opacity: hovered ? 1 : 0, y: hovered ? 0 : 8 }}
        transition={{ duration: 0.3 }}
      >
        {p.body}
      </motion.p>

      {/* Línea inferior */}
      <motion.div
        className={styles.pilarLine}
        animate={{ scaleX: hovered ? 1 : 0 }}
        transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
      />
    </motion.div>
  )
}

// ─────────────────────────────────────────────────────────────
// NOSOTROS
// ─────────────────────────────────────────────────────────────
export default function Nosotros() {
  return (
    <section className={styles.section} id="nosotros">

      {/* Flickering grid muy sutil de fondo */}
      <div className={styles.gridWrap}>
        <FlickeringGrid
          squareSize={3}
          gridGap={8}
          color="#94a3b8"
          maxOpacity={0.18}
          flickerChance={0.09}
        />
      </div>

      <div className={styles.content}>

        {/* ══ BLOQUE SUPERIOR: eyebrow + headline grande + logo ══ */}
        <div className={styles.topBlock}>
          <div className={styles.topLeft}>
            <motion.span
              className={styles.eyebrow}
              initial={{ opacity: 0, x: -16 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
            >
              — Nosotros
            </motion.span>

            <motion.h2
              className={styles.headline}
              initial={{ opacity: 0, y: 28 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.75, delay: 0.06, ease: [0.16, 1, 0.3, 1] }}
            >
              El futuro<br />
              <span className={styles.headlineLight}>ya no espera.</span>
            </motion.h2>

            <motion.p
              className={styles.lead}
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.18 }}
            >
              FrostFox es un ecosistema tech y educativo con una misión:
              que el talento no se desperdicie y ningún negocio se quede
              atrás por falta de presencia digital.
            </motion.p>
          </div>

          {/* Logo a la derecha — flotando, sin card */}
          <motion.div
            className={styles.logoFloatWrap}
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          >
            <motion.div
              className={styles.logoFloat}
              animate={{ y: [0, -7, 0] }}
              transition={{ duration: 3.4, repeat: Infinity, ease: "easeInOut" }}
            >
              <img src={ffLogo} alt="FrostFox" className={styles.logoImg} />
            </motion.div>
            <motion.svg
              className={styles.logoShadowSvg}
              viewBox="0 0 160 18"
              fill="none"
              animate={{ scaleX: [1, 0.65, 1], opacity: [0.25, 0.08, 0.25] }}
              transition={{ duration: 3.4, repeat: Infinity, ease: "easeInOut" }}
            >
              <ellipse cx="80" cy="9" rx="72" ry="7" fill="url(#sg)" />
              <defs>
                <radialGradient id="sg" cx="50%" cy="50%" r="50%">
                  <stop offset="0%"  stopColor="#0f172a" stopOpacity="0.4" />
                  <stop offset="100%" stopColor="#0f172a" stopOpacity="0" />
                </radialGradient>
              </defs>
            </motion.svg>
          </motion.div>
        </div>

        {/* ══ SEPARADOR CON CIFRAS ══ */}
        <div className={styles.statsStrip}>
          {[
            { val: "3", label: "pilares" },
            { val: "B2B", label: "enfoque" },
            { val: "48h", label: "respuesta" },
            { val: "0€", label: "consulta inicial" },
          ].map((s, i) => (
            <motion.div
              key={i}
              className={styles.stat}
              initial={{ opacity: 0, y: 12 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: i * 0.08 }}
            >
              <span className={styles.statVal}>{s.val}</span>
              <span className={styles.statLbl}>{s.label}</span>
            </motion.div>
          ))}
        </div>

        {/* ══ PILARES — tres cards con hover ══ */}
        <div className={styles.pilaresRow}>
          {PILARES.map((p, i) => (
            <PilarCard key={i} p={p} i={i} />
          ))}
        </div>

        {/* ══ CTA — tipografía grande, sin card ══ */}
        <div className={styles.ctaBlock}>
          <motion.p
            className={styles.ctaEyebrow}
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            ¿Tienes un proyecto?
          </motion.p>
          <motion.h3
            className={styles.ctaHeadline}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.65, ease: [0.16, 1, 0.3, 1] }}
          >
            Hablemos.
          </motion.h3>
          <motion.div
            className={styles.ctaActions}
            initial={{ opacity: 0, y: 12 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.15 }}
          >
            <motion.button
              className={styles.ctaPrimary}
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
            >
              Contactar →
            </motion.button>
            <motion.button
              className={styles.ctaSecondary}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.97 }}
            >
              Ver soluciones
            </motion.button>
          </motion.div>
        </div>

      </div>
    </section>
  )
}
