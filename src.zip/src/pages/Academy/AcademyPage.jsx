import { useEffect, useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import { motion, AnimatePresence } from 'motion/react'
import {
  Building2, UserCog, BookOpen, FileText, GraduationCap, Trophy,
  CheckCircle, ArrowRight, Zap, Shield, BarChart2, Clock,
  Users, Target, TrendingUp, Star
} from 'lucide-react'
import ffLogo from '../../assets/ff-logo-azul.webp'
import styles from './AcademyPage.module.css'

// ── URL de la app — cambiar cuando tengas dominio ──────────────
const APP_URL = 'https://frostfoxacademy.com'

// ── Halo con punto de luz ──────────────────────────────────────
function Halo({ size, opacity, duration, reverse = false, color = '#5de4ff', dotTop = true }) {
  return (
    <div
      className={styles.halo}
      style={{
        width: size, height: size,
        opacity,
        borderColor: color,
        animationDuration: `${duration}s`,
        animationDirection: reverse ? 'reverse' : 'normal',
        boxShadow: `0 0 ${size * 0.06}px ${color}20`,
      }}
    >
      {dotTop && (
        <div className={styles.haloDot} style={{
          background: color,
          boxShadow: `0 0 16px ${color}, 0 0 32px ${color}99, 0 0 48px ${color}40`,
        }} />
      )}
    </div>
  )
}

// ── Punto de dolor ─────────────────────────────────────────────
function PainPoint({ emoji, text, delay }) {
  return (
    <motion.div
      className={styles.painCard}
      initial={{ opacity: 0, x: -30 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay, ease: [0.16, 1, 0.3, 1] }}
    >
      <span className={styles.painEmoji}>{emoji}</span>
      <span className={styles.painText}>{text}</span>
    </motion.div>
  )
}

// ── Feature card ───────────────────────────────────────────────
function FeatureCard({ icon: Icon, title, desc, color, delay, size = 'normal' }) {
  return (
    <motion.div
      className={`${styles.featureCard} ${size === 'wide' ? styles.featureWide : ''}`}
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay, ease: [0.16, 1, 0.3, 1] }}
      style={{ '--card-color': color }}
    >
      <div className={styles.featureIcon} style={{ background: `${color}15`, color }}>
        <Icon size={20} strokeWidth={1.8} />
      </div>
      <div className={styles.featureBody}>
        <div className={styles.featureTitle}>{title}</div>
        <div className={styles.featureDesc}>{desc}</div>
      </div>
      <div className={styles.featureGlow} style={{ background: color }} />
    </motion.div>
  )
}

// ── Métrica ────────────────────────────────────────────────────
function Metric({ value, label, color, delay }) {
  return (
    <motion.div
      className={styles.metric}
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay }}
    >
      <div className={styles.metricVal} style={{ color }}>{value}</div>
      <div className={styles.metricLabel}>{label}</div>
    </motion.div>
  )
}

// ── Step del proceso ───────────────────────────────────────────
function Step({ num, title, desc, who, delay }) {
  return (
    <motion.div
      className={styles.step}
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay }}
    >
      <div className={styles.stepNum}>{num}</div>
      <div className={styles.stepBody}>
        <div className={styles.stepTitle}>{title}</div>
        <div className={styles.stepDesc}>{desc}</div>
      </div>
      <div className={styles.stepWho}>{who}</div>
    </motion.div>
  )
}

// ── Role tab ───────────────────────────────────────────────────
const ROLES = [
  {
    id: 'alumno', label: 'Alumno', color: '#0891b2',
    icon: GraduationCap,
    headline: 'El alumno estudia mejor, más rápido y con datos reales.',
    features: [
      'Tests autocorregidos con 3 modos: principiante, avanzado y examen',
      'Repetición espaciada automática de fallos',
      'Temario interactivo con subrayados y apuntes propios',
      'Estadísticas detalladas: sesiones, nota media, racha y progreso',
      'Sistema de XP, misiones y gamificación para mantener la constancia',
      'Supuestos prácticos con pistas y corrección inmediata',
    ],
  },
  {
    id: 'profesor', label: 'Profesor', color: '#7c3aed',
    icon: BookOpen,
    headline: 'El profesor sabe exactamente quién estudia y quién necesita ayuda.',
    features: [
      'Panel con todos los alumnos: nota, sesiones, racha y estado',
      'Alertas automáticas de alumnos en riesgo de abandono',
      'Banco de preguntas filtrable por bloque y búsqueda',
      'Tablón de avisos para comunicar novedades a la clase',
      'Plan semanal de estudio por bloques temáticos',
      'Exportar informe PDF completo de la clase',
    ],
  },
  {
    id: 'director', label: 'Director', color: '#059669',
    icon: Building2,
    headline: 'El director tiene visión de negocio real en tiempo real.',
    features: [
      'KPIs globales: alumnos activos, nota media, en riesgo, retención',
      'Rentabilidad por alumno y MRR calculado automáticamente',
      'Gestión de profesores, asignaturas y códigos de acceso',
      'Historial de facturas de FrostFox con descarga legal en PDF',
      'Informes PDF técnicos exportables',
      'Narrativa inteligente del estado de tu academia',
    ],
  },
]

function RoleSection() {
  const [active, setActive] = useState('alumno')
  const role = ROLES.find(r => r.id === active)
  const Icon = role.icon

  return (
    <div className={styles.roleWrap}>
      {/* Tabs */}
      <div className={styles.roleTabs}>
        {ROLES.map(r => (
          <button
            key={r.id}
            className={`${styles.roleTab} ${active === r.id ? styles.roleTabActive : ''}`}
            style={active === r.id ? { color: r.color, borderColor: `${r.color}50`, background: `${r.color}0d` } : {}}
            onClick={() => setActive(r.id)}
          >
            <r.icon size={15} strokeWidth={2} />
            {r.label}
          </button>
        ))}
      </div>

      {/* Panel */}
      <AnimatePresence mode="wait">
        <motion.div
          key={active}
          className={styles.rolePanel}
          style={{ borderColor: `${role.color}25` }}
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -12 }}
          transition={{ duration: 0.22 }}
        >
          {/* Glow top */}
          <div className={styles.rolePanelGlow} style={{ background: role.color }} />

          <div className={styles.roleHeader}>
            <div className={styles.roleIconWrap} style={{ background: `${role.color}15`, color: role.color }}>
              <Icon size={22} strokeWidth={1.8} />
            </div>
            <div>
              <div className={styles.roleLabel} style={{ color: role.color }}>{role.label}</div>
              <div className={styles.roleHeadline}>{role.headline}</div>
            </div>
          </div>

          <div className={styles.roleFeatures}>
            {role.features.map((f, i) => (
              <motion.div
                key={i}
                className={styles.roleFeature}
                initial={{ opacity: 0, x: -16 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.3, delay: i * 0.05 }}
              >
                <CheckCircle size={14} strokeWidth={2.5} style={{ color: role.color, flexShrink: 0, marginTop: 2 }} />
                <span>{f}</span>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  )
}

// ── PÁGINA PRINCIPAL ───────────────────────────────────────────
export default function AcademyPage() {
  // Scroll al top al montar
  useEffect(() => { window.scrollTo(0, 0) }, [])

  return (
    <div className={styles.page}>

      {/* ── NAVBAR MINI ── */}
      <nav className={styles.nav}>
        <Link to="/" className={styles.navLogo}>
          <img src={ffLogo} alt="FrostFox" className={styles.navLogoImg} />
          <span className={styles.navLogoText}>FrostFox <span className={styles.accent}>Academy</span></span>
        </Link>
        <div className={styles.navActions}>
          <Link to="/#contacto" className={styles.navContact}>Contactar ventas</Link>
          <a href={APP_URL} className={styles.navAcceder}>
            Acceder <ArrowRight size={14} strokeWidth={2.5} />
          </a>
        </div>
      </nav>

      {/* ── HERO ── */}
      <section className={styles.hero}>
        {/* Halos animados */}
        <div className={styles.halosWrap}>
          <Halo size={700} opacity={0.07} duration={22} color="#5de4ff" />
          <Halo size={520} opacity={0.12} duration={16} reverse color="#2563EB" />
          <Halo size={340} opacity={0.20} duration={10} color="#5de4ff" />
          <Halo size={180} opacity={0.30} duration={7}  reverse color="#5de4ff" dotTop={false} />
          {/* Orb central */}
          <div className={styles.orbCenter} />
        </div>

        {/* Contenido */}
        <div className={styles.heroContent}>
          <motion.div
            className={styles.heroBadge}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className={styles.badgeDot} />
            <span>SaaS B2B · Academias de oposiciones · España</span>
          </motion.div>

          <motion.h1
            className={styles.heroTitle}
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.1 }}
          >
            La plataforma que necesita<br />
            <span className={styles.accentGlow}>tu academia.</span>
          </motion.h1>

          <div className={styles.dividerLine} />

          <motion.p
            className={styles.heroSubtitle}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            Tests autocorregidos, temario estructurado, panel del profesor
            y visión de negocio real para el director. Todo en 48 horas.
          </motion.p>

          <motion.div
            className={styles.heroCtas}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.32 }}
          >
            <Link to="/#contacto" className={styles.ctaPrimary}>
              Solicitar demo gratuita →
            </Link>
            <a href={APP_URL} className={styles.ctaSecondary}>
              Ya soy usuario · Acceder
            </a>
          </motion.div>

          <motion.div
            className={styles.heroMeta}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.5 }}
          >
            <span>✓ Alta en 48h</span>
            <span>✓ Migración del temario incluida</span>
            <span>✓ Garantía 60 días</span>
          </motion.div>
        </div>
      </section>

      {/* ── EL PROBLEMA ── */}
      <section className={styles.section}>
        <div className={styles.container}>
          <motion.div
            className={styles.sectionHeader}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <span className={styles.pill} style={{ color: '#ef4444', borderColor: '#ef444430', background: '#ef44440d' }}>
              El problema
            </span>
            <h2 className={styles.sectionTitle}>
              ¿Te suena alguna<br />de estas situaciones?
            </h2>
          </motion.div>

          <div className={styles.painGrid}>
            <PainPoint emoji="📁" text="El temario está en PDFs que nadie sabe si leen o no." delay={0.1} />
            <PainPoint emoji="💬" text="Las dudas y avisos se pierden en grupos de WhatsApp." delay={0.18} />
            <PainPoint emoji="📊" text="No sabes qué alumnos estudian y cuáles están a punto de abandonar." delay={0.26} />
            <PainPoint emoji="😤" text="No tienes datos reales para tomar decisiones sobre tu academia." delay={0.34} />
            <PainPoint emoji="⏰" text="Preparar, corregir y hacer seguimiento te consume demasiado tiempo." delay={0.42} />
            <PainPoint emoji="💸" text="Tus alumnos pagan y no sabes si están aprovechando el servicio." delay={0.50} />
          </div>

          <motion.div
            className={styles.painSolution}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <div className={styles.painSolutionLine} />
            <span className={styles.painSolutionText}>
              FrostFox Academy resuelve todo esto. <span className={styles.accent}>Sin complicaciones técnicas.</span>
            </span>
            <div className={styles.painSolutionLine} />
          </motion.div>
        </div>
      </section>

      {/* ── CÓMO FUNCIONA — por rol ── */}
      <section className={styles.section}>
        <div className={styles.container}>
          <motion.div
            className={styles.sectionHeader}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <span className={styles.pill}>Cómo funciona</span>
            <h2 className={styles.sectionTitle}>
              Tres paneles.<br />
              <span className={styles.accent}>Un solo sistema.</span>
            </h2>
            <p className={styles.sectionSubtitle}>
              Cada rol tiene exactamente lo que necesita, sin sobrecarga de información.
            </p>
          </motion.div>

          <RoleSection />
        </div>
      </section>

      {/* ── FEATURES BENTO ── */}
      <section className={styles.section}>
        <div className={styles.container}>
          <motion.div
            className={styles.sectionHeader}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <span className={styles.pill}>Funcionalidades</span>
            <h2 className={styles.sectionTitle}>
              Todo lo que necesitas,<br />
              <span className={styles.accent}>desde el primer día.</span>
            </h2>
          </motion.div>

          <div className={styles.bentoGrid}>
            <FeatureCard icon={Zap} title="Alta en 48 horas" desc="De contrato firmado a academia operativa con el temario migrado. Nos encargamos de todo." color="#5de4ff" delay={0.05} size="wide" />
            <FeatureCard icon={BarChart2} title="Estadísticas en tiempo real" desc="Sesiones, nota media, racha, progreso por bloque. Sin esperar reportes manuales." color="#2563EB" delay={0.10} />
            <FeatureCard icon={Target} title="Repetición espaciada" desc="El sistema prioriza los fallos de cada alumno automáticamente." color="#7c3aed" delay={0.15} />
            <FeatureCard icon={Users} title="Multi-academia" desc="Gestiona varias academias, asignaturas y convocatorias desde un mismo panel." color="#059669" delay={0.20} />
            <FeatureCard icon={Shield} title="Garantía 60 días" desc="Si en 60 días no ves valor demostrable, te devolvemos el alta sin preguntas." color="#f59e0b" delay={0.25} />
            <FeatureCard icon={TrendingUp} title="Rentabilidad real" desc="MRR, ARR y retención calculados en tiempo real desde los datos de tu academia." color="#ec4899" delay={0.30} />
            <FeatureCard icon={FileText} title="Facturas legales" desc="Historial de facturas descargables en PDF con modelo legal español (RD 1619/2012)." color="#0891b2" delay={0.35} />
            <FeatureCard icon={Clock} title="Migración incluida" desc="El temario del BOE o convocatoria, convertido a 700+ preguntas estructuradas." color="#5de4ff" delay={0.40} size="wide" />
          </div>
        </div>
      </section>

      {/* ── PROCESO DE ALTA ── */}
      <section className={styles.section}>
        <div className={styles.container}>
          <motion.div
            className={styles.sectionHeader}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <span className={styles.pill} style={{ color: '#059669', borderColor: '#05996930', background: '#0599690d' }}>
              Proceso de alta
            </span>
            <h2 className={styles.sectionTitle}>
              Tu academia, operativa<br />
              <span className={styles.accent}>en 48 horas.</span>
            </h2>
            <p className={styles.sectionSubtitle}>
              Tú solo nos mandas el programa oficial. Nosotros hacemos el resto.
            </p>
          </motion.div>

          <div className={styles.steps}>
            <Step num="01" title="Nos mandas el programa oficial" desc="El BOE o la convocatoria de tu oposición. No necesitamos nada más." who="Tú" delay={0.1} />
            <Step num="02" title="Migramos el temario completo" desc="Bloques, temas y 700+ preguntas clasificadas con respuestas y explicaciones." who="Nosotros" delay={0.2} />
            <Step num="03" title="Configuramos tu academia" desc="Director, profesores y códigos de acceso para tus alumnos." who="Nosotros" delay={0.3} />
            <Step num="04" title="Sesión de onboarding (30 min)" desc="Tu equipo domina la plataforma desde el primer día. Incluida en el alta." who="Juntos" delay={0.4} />
          </div>

          <motion.div
            className={styles.guarantee}
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <span className={styles.guaranteeIcon}>🛡️</span>
            <div>
              <div className={styles.guaranteeTitle}>Garantía de devolución 60 días</div>
              <div className={styles.guaranteeDesc}>Si en 60 días no ves valor demostrable, te devolvemos el alta sin preguntas.</div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* ── MÉTRICAS ── */}
      <section className={styles.metricsSection}>
        <div className={styles.container}>
          <div className={styles.metricsGrid}>
            <Metric value="710+" label="Preguntas por temario migradas" color="#5de4ff" delay={0.0} />
            <Metric value="48h" label="De contrato a academia operativa" color="#059669" delay={0.1} />
            <Metric value="60d" label="Garantía de devolución" color="#f59e0b" delay={0.2} />
            <Metric value="3" label="Paneles: alumno, profesor y director" color="#7c3aed" delay={0.3} />
          </div>
        </div>
      </section>

      {/* ── PRECIOS ── */}
      <section className={styles.section}>
        <div className={styles.container}>
          <motion.div
            className={styles.sectionHeader}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <span className={styles.pill}>Precios</span>
            <h2 className={styles.sectionTitle}>
              Sin sorpresas.<br />
              <span className={styles.accent}>Sin letra pequeña.</span>
            </h2>
            <p className={styles.sectionSubtitle}>Precios sin IVA · Alta única desde 249 €</p>
          </motion.div>

          <div className={styles.plansGrid}>
            {[
              { name: 'Starter', price: '69', alumnos: '30', profesores: '1', asignaturas: '1' },
              { name: 'Growth',  price: '109', alumnos: '60', profesores: '3', asignaturas: '3', popular: true },
              { name: 'Academy', price: '169', alumnos: '100', profesores: '5', asignaturas: '5' },
              { name: 'Pro',     price: '249', alumnos: '∞', profesores: '∞', asignaturas: '∞' },
            ].map((plan, i) => (
              <motion.div
                key={plan.name}
                className={`${styles.planCard} ${plan.popular ? styles.planPopular : ''}`}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.08 }}
              >
                {plan.popular && <div className={styles.planBadge}>Más popular</div>}
                <div className={styles.planName}>{plan.name}</div>
                <div className={styles.planPrice}>
                  <span className={styles.planEur}>€</span>
                  <span className={styles.planAmount}>{plan.price}</span>
                  <span className={styles.planPeriod}>/mes</span>
                </div>
                <div className={styles.planFeatures}>
                  {[
                    `${plan.alumnos} alumnos`,
                    `${plan.profesores} ${plan.profesores === '1' ? 'profesor' : 'profesores'}`,
                    `${plan.asignaturas} ${plan.asignaturas === '1' ? 'asignatura' : 'asignaturas'}`,
                    'Migración incluida',
                    'Soporte incluido',
                  ].map((f, j) => (
                    <div key={j} className={styles.planFeature}>
                      <CheckCircle size={13} strokeWidth={2.5} style={{ color: plan.popular ? '#5de4ff' : '#059669' }} />
                      <span>{f}</span>
                    </div>
                  ))}
                </div>
                <Link to="/#contacto" className={`${styles.planCta} ${plan.popular ? styles.planCtaPopular : ''}`}>
                  Solicitar demo
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA FINAL ── */}
      <section className={styles.ctaSection}>
        <div className={styles.halosWrap} style={{ opacity: 0.6 }}>
          <Halo size={600} opacity={0.08} duration={20} color="#5de4ff" />
          <Halo size={420} opacity={0.14} duration={14} reverse color="#2563EB" />
          <Halo size={260} opacity={0.22} duration={9} color="#5de4ff" dotTop={false} />
          <div className={styles.orbCenter} />
        </div>
        <div className={styles.ctaContent}>
          <motion.img
            src={ffLogo}
            alt="FrostFox Academy"
            className={styles.ctaLogo}
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          />
          <motion.h2
            className={styles.ctaTitle}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
          >
            Tu academia digital,<br />
            <span className={styles.accentGlow}>empieza hoy.</span>
          </motion.h2>
          <motion.p
            className={styles.ctaSubtitle}
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            Alta en 48 horas · Migración incluida · Garantía 60 días
          </motion.p>
          <motion.div
            className={styles.heroCtas}
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.3 }}
          >
            <Link to="/#contacto" className={styles.ctaPrimary}>
              Solicitar demo gratuita →
            </Link>
            <a href={APP_URL} className={styles.ctaSecondary}>
              Ya soy usuario · Acceder
            </a>
          </motion.div>
        </div>
      </section>

      {/* ── FOOTER MINI ── */}
      <footer className={styles.footer}>
        <Link to="/" className={styles.footerBack}>← Volver a FrostFox</Link>
        <span className={styles.footerText}>FrostFox Academy · © {new Date().getFullYear()}</span>
        <a href={APP_URL} className={styles.footerAcceder}>Acceder a la plataforma</a>
      </footer>
    </div>
  )
}
